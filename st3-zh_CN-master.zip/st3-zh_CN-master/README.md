安装
----

- 去 [https://github.com/Ihavee/st3-zh_CN/releases/latest](https://github.com/Ihavee/st3-zh_CN/releases/latest) 下载最新的 `Default.sublime-package`文件
- 运行 Sublime Text 3，点击 Preferences -- Browse Packages，会打开 Packages 目录
- 将 Default.sublime-package 移动到 Packages 同层的 Install Packages 目录下即可。

参与
----

个别用语或许不符大家习惯，可以提交 issuses，群策群力。

如果您有兴趣一起参与，可以翻译所有 `*.sublime-menu` 文件，打包 sublime-package 方法：

	cd st3-zh_CN
	zip -x .git -x .gitignore -x README.md -rX9 Default.sublime-package *.*

最后，感谢朽木汉化！这里的中文化是在他的基础上进行的。
